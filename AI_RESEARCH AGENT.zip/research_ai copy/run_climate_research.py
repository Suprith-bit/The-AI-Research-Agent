#!/usr/bin/env python3
"""
Run Galileo with specific climate change and automotive industry query
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from galileo_optimized import OptimizedGalileo

def run_climate_automotive_research():
    """Run research on climate change policies and automotive industry"""

    print("🔬 PROJECT GALILEO - CLIMATE CHANGE & AUTOMOTIVE RESEARCH")
    print("=" * 70)

    # Your specific query
    topic = "How are climate change policies in Europe affecting automotive industry investments and what are the projected impacts through 2026?"
    depth = "expert"  # Using expert level for comprehensive analysis

    print(f"🎯 Research Topic: {topic}")
    print(f"📊 Analysis Level: {depth}")
    print("🚀 Starting research pipeline...\n")

    try:
        # Initialize Galileo
        galileo = OptimizedGalileo()

        # Run the research
        result = galileo.research_topic(topic, depth, force_new=True)

        if result and result['status'] == 'completed':
            print(f"\n✅ RESEARCH COMPLETED SUCCESSFULLY!")
            print(f"📄 Report saved to: {result.get('report_file')}")
            print(f"📊 Status: {result['status']}")

            # Show where the file is located
            report_file = result.get('report_file')
            if report_file:
                full_path = os.path.abspath(report_file)
                print(f"📍 Full path: {full_path}")

                # Check file size
                if os.path.exists(report_file):
                    file_size = os.path.getsize(report_file)
                    print(f"📏 File size: {file_size} bytes")

                    # Show first few lines of the report
                    print(f"\n📄 REPORT PREVIEW:")
                    print("-" * 50)
                    with open(report_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()[:20]
                        for line in lines:
                            print(line.rstrip())
                    print("-" * 50)

            # Demonstrate follow-up questions
            print(f"\n💬 TESTING FOLLOW-UP QUESTIONS:")
            followup_questions = [
                "What are the main policy impacts on electric vehicle investments?",
                "Which European countries have the strongest climate policies?",
                "What are the projected investment changes by 2026?"
            ]

            for question in followup_questions:
                print(f"\n❓ {question}")
                response = galileo.ask_followup(question)
                print(f"💬 {response[:300]}...")

        else:
            print(f"❌ Research failed!")
            if result:
                print(f"Status: {result.get('status')}")
                print(f"Error: {result.get('error', 'Unknown error')}")

    except Exception as e:
        print(f"❌ Critical error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_climate_automotive_research()