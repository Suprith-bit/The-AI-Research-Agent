import requests
from bs4 import BeautifulSoup
from config import Config
import time
import re

class WebScout:
    def __init__(self):
        self.serper_key = Config.SERPER_API_KEY
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def search_web(self, query):
        """Search using Serper API"""
        url = "https://google.serper.dev/search"
        payload = {
            'q': query,
            'num': Config.MAX_SEARCH_RESULTS
        }
        headers = {
            'X-API-KEY': self.serper_key,
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=Config.REQUEST_TIMEOUT)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Search error for query '{query}': {e}")
            return {'organic': []}
    
    def scrape_content(self, url):
        """Scrape content from URL using BeautifulSoup"""
        for attempt in range(Config.MAX_SCRAPE_ATTEMPTS):
            try:
                response = self.session.get(url, timeout=Config.REQUEST_TIMEOUT)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Remove unwanted elements
                for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'advertisement']):
                    tag.decompose()
                
                content = self._extract_main_content(soup)
                
                if content and len(content.strip()) > 100:  # Minimum content length
                    return {
                        'url': url,
                        'content': content,
                        'title': soup.title.string.strip() if soup.title else '',
                        'length': len(content)
                    }
                
            except Exception as e:
                print(f"Scraping error (attempt {attempt + 1}) for {url}: {e}")
                if attempt < Config.MAX_SCRAPE_ATTEMPTS - 1:
                    time.sleep(1)  # Wait before retry
        
        return None
    
    def _extract_main_content(self, soup):
        """Extract clean text from HTML soup"""
        # Priority order for content extraction
        content_selectors = [
            'article',
            '[role="main"]',
            '.content',
            '.main-content',
            '#content',
            '.entry-content',
            '.post-content'
        ]
        
        # Try to find main content area
        main_content = None
        for selector in content_selectors:
            elements = soup.select(selector)
            if elements:
                main_content = elements[0]
                break
        
        # Fallback to body if no main content found
        if not main_content:
            main_content = soup.find('body') or soup
        
        # Extract text and clean it
        text = main_content.get_text(separator=' ', strip=True)
        
        # Clean up text
        text = re.sub(r'\s+', ' ', text)  # Normalize whitespace
        text = re.sub(r'\n+', '\n', text)  # Normalize newlines
        
        return text[:5000]  # Limit content length
