from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from config import Config
import re

class InformationAnalyst:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model=Config.GEMINI_MODEL,
            temperature=Config.TEMPERATURE,
            google_api_key=Config.GOOGLE_API_KEY
        )
    
    def analyze_content(self, collected_data, sub_questions):
        """Analyze scraped content and extract relevant information"""
        if not collected_data:
            return {"analysis": "No data collected", "facts_by_source": {}, "contradictions": []}
        
        analysis_results = []
        facts_by_source = {}
        
        for i, question in enumerate(sub_questions):
            relevant_sources = self._find_relevant_sources(question, collected_data)
            
            if relevant_sources:
                extracted_facts = self._extract_facts_for_question(question, relevant_sources)
                analysis_results.append({
                    'question': question,
                    'facts': extracted_facts,
                    'sources': [source['url'] for source in relevant_sources]
                })
                
                # Group facts by topic for contradiction detection
                topic_key = f"question_{i}"
                facts_by_source[topic_key] = extracted_facts
        
        # Detect contradictions
        contradictions = self.detect_contradictions(facts_by_source)
        
        return {
            'analysis': analysis_results,
            'facts_by_source': facts_by_source,
            'contradictions': contradictions
        }
    
    def _find_relevant_sources(self, question, collected_data):
        """Find sources most relevant to the question"""
        relevant = []
        question_keywords = set(question.lower().split())
        
        for data in collected_data:
            if not data or not data.get('content'):
                continue
                
            content_lower = data['content'].lower()
            # Simple relevance scoring based on keyword overlap
            overlap = sum(1 for word in question_keywords if word in content_lower)
            
            if overlap >= 2:  # Minimum keyword threshold
                relevant.append({
                    'url': data['url'],
                    'content': data['content'],
                    'title': data.get('title', ''),
                    'relevance_score': overlap
                })
        
        # Sort by relevance and return top sources
        relevant.sort(key=lambda x: x['relevance_score'], reverse=True)
        return relevant[:3]  # Top 3 most relevant sources
    
    def _extract_facts_for_question(self, question, sources):
        """Extract specific facts that answer the question"""
        if not sources:
            return []
        
        # Combine content from all sources
        combined_content = "\n\n".join([
            f"Source: {source['url']}\nContent: {source['content'][:1000]}"
            for source in sources
        ])
        
        prompt = PromptTemplate(
            input_variables=["question", "content"],
            template="""Extract specific facts that directly answer this question: {question}

Content from sources:
{content}

Return facts as a list, each with its source URL. Format:
- Fact 1 [source_url]
- Fact 2 [source_url]

Only include facts that directly answer the question. Be concise and accurate."""
        )
        
        try:
            response = self.llm.invoke(prompt.format(question=question, content=combined_content))
            facts = self._parse_facts_with_sources(response.content, sources)
            return facts
        except Exception as e:
            print(f"Error extracting facts for question '{question}': {e}")
            return []
    
    def _parse_facts_with_sources(self, response_text, sources):
        """Parse facts and associate them with source URLs"""
        facts = []
        lines = response_text.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if line.startswith('-') or line.startswith('•'):
                # Extract fact and try to find source URL
                fact_text = line.lstrip('-•').strip()
                
                # Look for URL in brackets
                url_match = re.search(r'\[(https?://[^\]]+)\]', fact_text)
                if url_match:
                    source_url = url_match.group(1)
                    fact_clean = re.sub(r'\[https?://[^\]]+\]', '', fact_text).strip()
                else:
                    # Assign to first source if no URL found
                    source_url = sources[0]['url'] if sources else ''
                    fact_clean = fact_text
                
                if fact_clean:
                    facts.append({
                        'fact': fact_clean,
                        'source_url': source_url
                    })
        
        return facts
    
    def detect_contradictions(self, facts_by_source):
        """Compare facts from different sources to detect contradictions"""
        contradictions = []
        
        if len(facts_by_source) < 2:
            return contradictions
        
        # Compare facts across different topics/questions
        topics = list(facts_by_source.keys())
        
        for i in range(len(topics)):
            for j in range(i + 1, len(topics)):
                topic1, topic2 = topics[i], topics[j]
                facts1 = facts_by_source[topic1]
                facts2 = facts_by_source[topic2]
                
                if not facts1 or not facts2:
                    continue
                
                # Use LLM to compare statements
                comparison_text1 = " ".join([f['fact'] for f in facts1 if isinstance(f, dict)])
                comparison_text2 = " ".join([f['fact'] for f in facts2 if isinstance(f, dict)])
                
                if not comparison_text1 or not comparison_text2:
                    continue
                
                comparison_prompt = f"""
                Compare these two sets of statements and identify any contradictions:
                
                Set 1: {comparison_text1}
                Set 2: {comparison_text2}
                
                Are there any direct contradictions? If yes, explain them clearly.
                If no contradictions, respond with "No contradictions found."
                """
                
                try:
                    result = self.llm.invoke(comparison_prompt)
                    if "contradiction" in result.content.lower() and "no contradictions" not in result.content.lower():
                        contradictions.append({
                            'topics': [topic1, topic2],
                            'contradiction': result.content,
                            'sources1': [f['source_url'] for f in facts1 if isinstance(f, dict)],
                            'sources2': [f['source_url'] for f in facts2 if isinstance(f, dict)]
                        })
                except Exception as e:
                    print(f"Error in contradiction detection: {e}")
                    continue
        
        return contradictions
