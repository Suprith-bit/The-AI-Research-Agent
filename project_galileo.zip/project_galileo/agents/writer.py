from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from config import Config
from datetime import datetime

class ReportWriter:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model=Config.GEMINI_MODEL,
            temperature=Config.TEMPERATURE,
            google_api_key=Config.GOOGLE_API_KEY
        )
    
    def generate_report(self, main_query, analysis_data):
        """Generate comprehensive research report with citations"""
        if not analysis_data or not analysis_data.get('analysis'):
            return self._generate_empty_report(main_query)
        
        # Prepare data for report generation
        analysis = analysis_data['analysis']
        contradictions = analysis_data.get('contradictions', [])
        
        # Generate main report sections
        executive_summary = self._generate_executive_summary(main_query, analysis)
        detailed_findings = self._generate_detailed_findings(analysis)
        contradiction_section = self._generate_contradiction_section(contradictions)
        
        # Compile final report
        report = self._compile_final_report(
            main_query, 
            executive_summary, 
            detailed_findings, 
            contradiction_section,
            analysis
        )
        
        return report
    
    def _generate_executive_summary(self, main_query, analysis):
        """Generate executive summary of findings"""
        # Collect key facts from all analysis
        all_facts = []
        all_sources = set()
        
        for item in analysis:
            facts = item.get('facts', [])
            for fact in facts:
                if isinstance(fact, dict):
                    all_facts.append(fact['fact'])
                    all_sources.add(fact['source_url'])
        
        facts_text = " ".join(all_facts[:10])  # Top 10 facts for summary
        
        prompt = PromptTemplate(
            input_variables=["query", "facts"],
            template="""Create a concise executive summary for this research query: {query}

Key findings from research:
{facts}

Write a 3-4 sentence executive summary that captures the most important insights. 
Be factual and direct. Do not include citations in the summary."""
        )
        
        try:
            response = self.llm.invoke(prompt.format(query=main_query, facts=facts_text))
            return response.content.strip()
        except Exception as e:
            print(f"Error generating executive summary: {e}")
            return "Research completed on the provided query with multiple sources analyzed."
    
    def _generate_detailed_findings(self, analysis):
        """Generate detailed findings section with proper citations"""
        sections = []
        
        for i, item in enumerate(analysis, 1):
            question = item['question']
            facts = item.get('facts', [])
            
            if not facts:
                continue
            
            section_content = f"### {question}\n\n"
            
            for fact in facts:
                if isinstance(fact, dict) and fact.get('fact') and fact.get('source_url'):
                    section_content += f"- {fact['fact']} [{fact['source_url']}]\n"
            
            section_content += "\n"
            sections.append(section_content)
        
        return "".join(sections)
    
    def _generate_contradiction_section(self, contradictions):
        """Generate section highlighting any contradictions found"""
        if not contradictions:
            return ""
        
        section = "## Contradictions and Conflicting Information\n\n"
        section += "The following contradictions were identified in the source materials:\n\n"
        
        for i, contradiction in enumerate(contradictions, 1):
            section += f"### Contradiction {i}\n\n"
            section += f"{contradiction['contradiction']}\n\n"
            
            # Add source references
            sources = set(contradiction.get('sources1', []) + contradiction.get('sources2', []))
            if sources:
                section += "**Conflicting Sources:**\n"
                for source in sources:
                    section += f"- {source}\n"
            section += "\n"
        
        return section
    
    def _compile_final_report(self, main_query, executive_summary, detailed_findings, contradiction_section, analysis):
        """Compile all sections into final report"""
        # Count sources
        all_sources = set()
        for item in analysis:
            all_sources.update(item.get('sources', []))
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        report = f"""# Research Report: {main_query}

**Generated:** {timestamp}  
**Sources Analyzed:** {len(all_sources)}

## Executive Summary

{executive_summary}

## Detailed Findings

{detailed_findings}

{contradiction_section}

## Methodology

This report was generated using autonomous AI research methodology:
1. **Query Decomposition:** The main question was broken down into specific sub-questions
2. **Web Search:** Each sub-question was researched using web search APIs  
3. **Content Analysis:** Relevant sources were scraped and analyzed for factual content
4. **Synthesis:** Information was synthesized and cross-referenced for contradictions
5. **Report Generation:** Findings were compiled with proper source citations

## Sources

The following sources were consulted in this research:

"""
        
        # Add source list
        for i, source in enumerate(sorted(all_sources), 1):
            report += f"{i}. {source}\n"
        
        report += f"\n---\n*Report generated by Project Galileo AI Research Agent*"
        
        return report
    
    def _generate_empty_report(self, main_query):
        """Generate report when no data was collected"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        return f"""# Research Report: {main_query}

**Generated:** {timestamp}  
**Status:** No data collected

## Summary

Unable to generate research findings due to:
- No search results found
- All sources failed to load
- Content extraction issues

Please try:
- Rephrasing the query
- Checking internet connection
- Verifying API keys

---
*Report generated by Project Galileo AI Research Agent*
"""

    def format_citations(self, report):
        """Ensure proper citation formatting throughout the report"""
        # This method can be used to clean up citation formatting if needed
        return report
