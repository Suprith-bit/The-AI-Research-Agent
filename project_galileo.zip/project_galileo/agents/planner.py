from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from config import Config

class QueryPlanner:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model=Config.GEMINI_MODEL,
            temperature=Config.TEMPERATURE,
            google_api_key=Config.GOOGLE_API_KEY
        )
    
    def decompose_query(self, main_query):
        """Break down complex query into searchable sub-questions"""
        prompt = PromptTemplate(
            input_variables=["query"],
            template="""Break down this complex research question into 4-5 specific, 
            searchable sub-questions that will help answer the main query comprehensively.
            
            Main Query: {query}
            
            Return ONLY the sub-questions as a numbered list:
            1.
            2.
            3.
            4.
            5."""
        )
        
        try:
            response = self.llm.invoke(prompt.format(query=main_query))
            sub_questions = self._parse_subquestions(response.content)
            return sub_questions
        except Exception as e:
            print(f"Error in query decomposition: {e}")
            return [main_query]  # Fallback to original query
    
    def _parse_subquestions(self, response_text):
        """Parse numbered list of sub-questions from LLM response"""
        lines = response_text.strip().split('\n')
        sub_questions = []
        
        for line in lines:
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                # Remove numbering and clean up
                question = line.split('.', 1)[-1].strip()
                if question:
                    sub_questions.append(question)
        
        return sub_questions[:5]  # Limit to 5 questions
