from langchain_google_genai import ChatGoogleGenerativeAI

from config import Config

class InteractiveAgent:
    def __init__(self, main_agent):
        self.agent = main_agent
        self.knowledge_base = {}
        self.conversation_history = []
        
        self.llm = ChatGoogleGenerativeAI(
            model=Config.GEMINI_MODEL,
            temperature=Config.TEMPERATURE,
            api_key=Config.GOOGLE_API_KEY
        )
    
    def store_research_data(self, query, research_results):
        """Store research results for future reference"""
        self.knowledge_base[query] = {
            'results': research_results,
            'timestamp': self._get_timestamp()
        }
    
    def chat(self, follow_up_question):
        """Handle follow-up questions using collected knowledge"""
        # Find relevant data from knowledge base
        relevant_data = self.find_relevant_data(follow_up_question)
        
        # Generate contextual response
        response = self.generate_contextual_response(follow_up_question, relevant_data)
        
        # Store conversation
        self.conversation_history.append({
            'question': follow_up_question,
            'answer': response,
            'timestamp': self._get_timestamp()
        })
        
        return response
    
    def find_relevant_data(self, question):
        """Find relevant data from knowledge base for the question"""
        relevant_data = []
        question_lower = question.lower()
        question_keywords = set(question_lower.split())
        
        for query, data in self.knowledge_base.items():
            # Simple keyword matching
            query_lower = query.lower()
            overlap = sum(1 for word in question_keywords if word in query_lower)
            
            if overlap >= 1:  # At least one keyword match
                relevant_data.append({
                    'original_query': query,
                    'data': data['results'],
                    'relevance_score': overlap
                })
        
        # Sort by relevance
        relevant_data.sort(key=lambda x: x['relevance_score'], reverse=True)
        return relevant_data[:3]  # Top 3 most relevant
    
    def generate_contextual_response(self, question, relevant_data):
        """Generate response using relevant knowledge base data"""
        if not relevant_data:
            return "I don't have enough information in my knowledge base to answer that question. Please ask me to research this topic first."
        
        # Prepare context from relevant data
        context_text = ""
        for item in relevant_data:
            if 'analysis' in item['data']:
                analysis = item['data']['analysis']
                for analysis_item in analysis:
                    facts = analysis_item.get('facts', [])
                    for fact in facts:
                        if isinstance(fact, dict):
                            context_text += f"- {fact['fact']} [{fact['source_url']}]\n"
        
        prompt = f"""Based on my previous research, answer this follow-up question: {question}

Available context from research:
{context_text}

Provide a helpful answer using the available information. Include citations where appropriate.
If the available information doesn't fully answer the question, acknowledge this limitation."""
        
        try:
            response = self.llm.invoke(prompt)
            return response.content
        except Exception as e:
            return f"Error generating response: {e}"
    
    def get_conversation_summary(self):
        """Get summary of conversation history"""
        if not self.conversation_history:
            return "No conversation history available."
        
        summary = "## Conversation Summary\n\n"
        for i, item in enumerate(self.conversation_history, 1):
            summary += f"**Q{i}:** {item['question']}\n"
            summary += f"**A{i}:** {item['answer'][:200]}{'...' if len(item['answer']) > 200 else ''}\n\n"
        
        return summary
    
    def _get_timestamp(self):
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
