import json
from datetime import datetime

class OutputFormatter:
    def __init__(self):
        pass
    
    def generate_structured_output(self, main_query, analysis_data):
        """Generate structured JSON output from research results"""
        if not analysis_data or not analysis_data.get('analysis'):
            return self._empty_structured_output(main_query)
        
        analysis = analysis_data['analysis']
        contradictions = analysis_data.get('contradictions', [])
        
        structured = {
            "metadata": {
                "main_query": main_query,
                "generated_at": datetime.now().isoformat(),
                "total_sources": self._count_unique_sources(analysis),
                "total_findings": len(analysis)
            },
            "findings": self._extract_findings(analysis),
            "risks": self._extract_risks(analysis),
            "timeline_analysis": self._extract_timeline_info(analysis),
            "contradictions": self._format_contradictions(contradictions),
            "sources": self._extract_all_sources(analysis),
            "confidence_scores": self._calculate_confidence_scores(analysis)
        }
        
        return json.dumps(structured, indent=2)
    
    def _extract_findings(self, analysis):
        """Extract key findings from analysis"""
        findings = []
        
        for item in analysis:
            question = item['question']
            facts = item.get('facts', [])
            
            for fact in facts:
                if isinstance(fact, dict):
                    findings.append({
                        "finding": fact['fact'],
                        "category": self._categorize_finding(question, fact['fact']),
                        "source": fact['source_url'],
                        "confidence": "medium"  # Default confidence
                    })
        
        return findings
    
    def _extract_risks(self, analysis):
        """Extract risk-related information"""
        risks = []
        risk_keywords = ['risk', 'threat', 'danger', 'problem', 'challenge', 'issue', 'concern']
        
        for item in analysis:
            facts = item.get('facts', [])
            
            for fact in facts:
                if isinstance(fact, dict):
                    fact_lower = fact['fact'].lower()
                    if any(keyword in fact_lower for keyword in risk_keywords):
                        risks.append({
                            "risk": fact['fact'],
                            "impact": self._assess_impact(fact['fact']),
                            "timeline": "unknown",
                            "evidence": [fact['source_url']]
                        })
        
        return risks
    
    def _extract_timeline_info(self, analysis):
        """Extract timeline-related information"""
        timeline = {
            "short_term": [],
            "medium_term": [],
            "long_term": [],
            "immediate": []
        }
        
        timeline_indicators = {
            "immediate": ["immediately", "now", "urgent", "current"],
            "short_term": ["months", "quarter", "short-term", "near-term", "soon"],
            "medium_term": ["year", "annual", "medium-term", "mid-term"],
            "long_term": ["years", "decade", "long-term", "future", "eventually"]
        }
        
        for item in analysis:
            facts = item.get('facts', [])
            
            for fact in facts:
                if isinstance(fact, dict):
                    fact_lower = fact['fact'].lower()
                    
                    for period, indicators in timeline_indicators.items():
                        if any(indicator in fact_lower for indicator in indicators):
                            timeline[period].append({
                                "item": fact['fact'],
                                "source": fact['source_url']
                            })
                            break
        
        return timeline
    
    def _format_contradictions(self, contradictions):
        """Format contradictions for structured output"""
        formatted = []
        
        for contradiction in contradictions:
            formatted.append({
                "description": contradiction['contradiction'],
                "conflicting_sources": list(set(
                    contradiction.get('sources1', []) + 
                    contradiction.get('sources2', [])
                )),
                "severity": "medium"
            })
        
        return formatted
    
    def _extract_all_sources(self, analysis):
        """Extract all unique sources"""
        sources = set()
        
        for item in analysis:
            sources.update(item.get('sources', []))
            
            facts = item.get('facts', [])
            for fact in facts:
                if isinstance(fact, dict) and fact.get('source_url'):
                    sources.add(fact['source_url'])
        
        return list(sources)
    
    def _calculate_confidence_scores(self, analysis):
        """Calculate confidence scores for the analysis"""
        total_sources = self._count_unique_sources(analysis)
        total_facts = sum(len(item.get('facts', [])) for item in analysis)
        
        confidence = {
            "overall_confidence": "medium",
            "source_diversity": "high" if total_sources > 10 else "medium" if total_sources > 5 else "low",
            "fact_coverage": "high" if total_facts > 15 else "medium" if total_facts > 8 else "low",
            "metrics": {
                "total_sources": total_sources,
                "total_facts": total_facts,
                "avg_facts_per_question": total_facts / max(len(analysis), 1)
            }
        }
        
        return confidence
    
    def _categorize_finding(self, question, fact):
        """Categorize finding based on question and content"""
        question_lower = question.lower()
        fact_lower = fact.lower()
        
        if any(word in question_lower for word in ['risk', 'threat', 'danger']):
            return "risk_assessment"
        elif any(word in question_lower for word in ['policy', 'regulation', 'law']):
            return "regulatory"
        elif any(word in question_lower for word in ['market', 'economic', 'financial']):
            return "market_analysis"
        elif any(word in question_lower for word in ['technology', 'technical', 'innovation']):
            return "technology"
        else:
            return "general"
    
    def _assess_impact(self, fact):
        """Assess impact level of a risk or finding"""
        fact_lower = fact.lower()
        
        high_impact_words = ['critical', 'severe', 'major', 'significant', 'substantial']
        medium_impact_words = ['moderate', 'considerable', 'notable', 'important']
        
        if any(word in fact_lower for word in high_impact_words):
            return "high"
        elif any(word in fact_lower for word in medium_impact_words):
            return "medium"
        else:
            return "low"
    
    def _count_unique_sources(self, analysis):
        """Count unique sources across all analysis"""
        sources = set()
        
        for item in analysis:
            sources.update(item.get('sources', []))
        
        return len(sources)
    
    def _empty_structured_output(self, main_query):
        """Generate empty structured output when no data available"""
        empty_structure = {
            "metadata": {
                "main_query": main_query,
                "generated_at": datetime.now().isoformat(),
                "total_sources": 0,
                "total_findings": 0,
                "status": "no_data_collected"
            },
            "findings": [],
            "risks": [],
            "timeline_analysis": {
                "short_term": [],
                "medium_term": [],
                "long_term": [],
                "immediate": []
            },
            "contradictions": [],
            "sources": [],
            "confidence_scores": {
                "overall_confidence": "none",
                "source_diversity": "none",
                "fact_coverage": "none",
                "metrics": {
                    "total_sources": 0,
                    "total_facts": 0,
                    "avg_facts_per_question": 0
                }
            }
        }
        
        return json.dumps(empty_structure, indent=2)
