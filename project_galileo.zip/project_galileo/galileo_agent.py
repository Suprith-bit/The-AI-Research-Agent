from agents import QueryPlanner, WebScout, InformationAnalyst, ReportWriter
from utils import InteractiveAgent, OutputFormatter
import time

class GalileoAgent:
    def __init__(self):
        """Initialize all agent components"""
        self.planner = QueryPlanner()
        self.scout = WebScout()
        self.analyst = InformationAnalyst()
        self.writer = ReportWriter()
        self.output_formatter = OutputFormatter()
        
        # Initialize interactive capabilities
        self.interactive_agent = InteractiveAgent(self)
        
        print("🛰️ Project Galileo initialized successfully!")
    
    def research(self, main_query, depth="normal"):
        """Execute full research workflow"""
        print(f"\n🔍 Starting research: {main_query}")
        print("=" * 60)
        
        try:
            # Step 1: Decompose query
            print("📋 Step 1: Decomposing query...")
            sub_questions = self.planner.decompose_query(main_query)
            print(f"   Generated {len(sub_questions)} sub-questions")
            
            # Step 2: Search and collect data
            print("🌐 Step 2: Searching and collecting data...")
            collected_data = []
            
            for i, question in enumerate(sub_questions, 1):
                print(f"   Researching question {i}/{len(sub_questions)}: {question[:50]}...")
                
                search_results = self.scout.search_web(question)
                question_data = []
                
                for result in search_results.get('organic', []):
                    content = self.scout.scrape_content(result.get('link', ''))
                    if content:
                        collected_data.append(content)
                        question_data.append(content)
                
                print(f"   Collected {len(question_data)} sources for this question")
                time.sleep(1)  # Rate limiting
            
            print(f"   Total sources collected: {len(collected_data)}")
            
            # Step 3: Analyze and extract information
            print("🔬 Step 3: Analyzing content...")
            analysis = self.analyst.analyze_content(collected_data, sub_questions)
            print(f"   Analysis complete. Found {len(analysis.get('contradictions', []))} contradictions")
            
            # Step 4: Generate report
            print("📄 Step 4: Generating report...")
            report = self.writer.generate_report(main_query, analysis)
            
            # Store results for interactive use
            self.interactive_agent.store_research_data(main_query, analysis)
            
            print("✅ Research complete!")
            return {
                'report': report,
                'structured_data': analysis,
                'sub_questions': sub_questions,
                'sources_count': len(collected_data)
            }
            
        except Exception as e:
            print(f"❌ Error during research: {e}")
            return {
                'report': f"# Research Error\n\nFailed to complete research for: {main_query}\n\nError: {e}",
                'structured_data': {},
                'sub_questions': [],
                'sources_count': 0
            }
    
    def chat(self, follow_up_question):
        """Handle follow-up questions interactively"""
        return self.interactive_agent.chat(follow_up_question)
    
    def export_structured_data(self, main_query, analysis_data):
        """Export research results in structured JSON format"""
        return self.output_formatter.generate_structured_output(main_query, analysis_data)
    
    def get_research_summary(self):
        """Get summary of all research conducted"""
        return self.interactive_agent.get_conversation_summary()
