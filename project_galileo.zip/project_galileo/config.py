import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
    SERPER_API_KEY = os.getenv("SERPER_API_KEY")
    GEMINI_MODEL = "gemini-1.5-flash"
    TEMPERATURE = 0.3
    MAX_TOKENS = 2000
    MAX_SEARCH_RESULTS = 5
    MAX_SCRAPE_ATTEMPTS = 3
    REQUEST_TIMEOUT = 10
    REPORT_FORMAT = "markdown"
    CITATION_FORMAT = "[{url}]"
