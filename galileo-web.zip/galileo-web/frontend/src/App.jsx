import { useState } from 'react'
import axios from 'axios'
import ReactMarkdown from 'react-markdown'
import './App.css'

const moonriseColors = {
  primary: "#E25822",
  secondary: "#395144",
  accent: "#F8B400",
  background: "#F2E1AC",
  textPrimary: "#2C2A2A",
}

function App() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleResearch = async (e) => {
    e.preventDefault()
    if (!query.trim()) return

    setLoading(true)
    setError('')
    setResults(null)

    try {
      const response = await axios.post('http://localhost:8000/api/research', {
        query: query.trim()
      }, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 300000
      })
      
      if (response.data) {
        setResults(response.data)
      } else {
        setError('No research results received')
      }
      
    } catch (err) {
      setError('Research failed. Please try again.')
    }
    
    setLoading(false)
  }

  return (
    <div style={{
      backgroundColor: moonriseColors.background,
      minHeight: '100vh',
      padding: '2rem',
      fontFamily: 'Georgia, serif'
    }}>
      <h1 style={{ 
        color: moonriseColors.primary, 
        textAlign: 'center',
        fontSize: '3rem',
        marginBottom: '1rem'
      }}>
        🛰️ Project Galileo
      </h1>
      
      <p style={{ 
        textAlign: 'center', 
        color: moonriseColors.secondary,
        fontSize: '1.2rem',
        marginBottom: '2rem'
      }}>
        Autonomous AI Research Agent
      </p>
      
      <form onSubmit={handleResearch} style={{ 
        textAlign: 'center', 
        margin: '2rem 0',
        backgroundColor: 'white',
        padding: '2rem',
        borderRadius: '10px',
        boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
      }}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your research question..."
          style={{
            width: '70%',
            padding: '1rem',
            fontSize: '1rem',
            border: `3px solid ${moonriseColors.primary}`,
            borderRadius: '8px',
            marginRight: '1rem',
            outline: 'none'
          }}
        />
        <button 
          type="submit" 
          disabled={loading}
          style={{
            padding: '1rem 2rem',
            backgroundColor: moonriseColors.primary,
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: loading ? 'not-allowed' : 'pointer',
            fontSize: '1rem',
            fontWeight: 'bold',
            opacity: loading ? 0.7 : 1
          }}
        >
          {loading ? '🔍 Researching...' : '🚀 Research'}
        </button>
      </form>

      {error && (
        <div style={{
          backgroundColor: '#ff6b6b',
          color: 'white',
          padding: '1rem',
          borderRadius: '5px',
          textAlign: 'center',
          margin: '1rem 0'
        }}>
          {error}
        </div>
      )}

      {loading && (
        <div style={{
          textAlign: 'center',
          color: moonriseColors.secondary,
          fontSize: '1.1rem',
          margin: '2rem 0'
        }}>
          <div>🔍 Conducting autonomous research...</div>
          <div style={{ fontSize: '0.9rem', marginTop: '0.5rem' }}>
            Analyzing web sources and generating insights...
          </div>
        </div>
      )}

      {results && results.report && (
        <div style={{
          backgroundColor: 'white',
          padding: '2rem',
          borderRadius: '10px',
          marginTop: '2rem',
          boxShadow: '0 6px 12px rgba(0,0,0,0.1)',
          maxHeight: '70vh',
          overflowY: 'auto'
        }}>
          <div style={{
            backgroundColor: moonriseColors.accent,
            padding: '1rem',
            borderRadius: '5px',
            marginBottom: '2rem',
            textAlign: 'center',
            fontSize: '0.9rem',
            color: moonriseColors.textPrimary
          }}>
            📊 Research completed • {results.sources_count || 0} sources analyzed • {results.sub_questions?.length || 0} sub-questions explored
          </div>
          
          <div style={{ 
            lineHeight: '1.6', 
            fontSize: '16px',
            color: moonriseColors.textPrimary 
          }}>
            <ReactMarkdown>{results.report}</ReactMarkdown>
          </div>
        </div>
      )}

      {results && !results.report && (
        <div style={{
          backgroundColor: 'white',
          padding: '2rem',
          borderRadius: '10px',
          marginTop: '2rem',
          textAlign: 'center',
          color: moonriseColors.secondary
        }}>
          <p>Research completed but no report content was generated.</p>
          <p>Sources found: {results.sources_count || 0}</p>
        </div>
      )}
    </div>
  )
}

export default App
