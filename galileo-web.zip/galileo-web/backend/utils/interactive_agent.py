from groq import Groq
from config import Config

class InteractiveAgent:
    def __init__(self, galileo_agent):
        self.galileo_agent = galileo_agent
        self.client = Groq(api_key=Config.GROQ_API_KEY)
        self.conversation_history = []
        self.research_data = {}
    
    def store_research_data(self, query, analysis_data):
        """Store research results for interactive use"""
        self.research_data[query] = analysis_data
    
    def chat(self, follow_up_question):
        """Handle follow-up questions about research"""
        try:
            # Get context from stored research
            context = ""
            for query, data in self.research_data.items():
                context += f"Research Query: {query}\n"
                context += f"Findings: {data.get('findings', 'No findings')}\n\n"
            
            prompt = f"""Based on this research context:
{context}

Answer this follow-up question: "{follow_up_question}"

Provide a helpful, specific answer based on the research data."""
            
            response = self.client.chat.completions.create(
                model=Config.GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=Config.TEMPERATURE
            )
            
            answer = response.choices[0].message.content
            
            # Store in conversation history
            self.conversation_history.append({
                'question': follow_up_question,
                'answer': answer
            })
            
            return answer
            
        except Exception as e:
            return f"Sorry, I encountered an error: {str(e)}"
    
    def get_conversation_summary(self):
        """Get summary of conversation"""
        if not self.conversation_history:
            return "No conversation history available."
        
        summary = "Conversation Summary:\n"
        for i, exchange in enumerate(self.conversation_history, 1):
            summary += f"{i}. Q: {exchange['question']}\n"
            summary += f"   A: {exchange['answer'][:100]}...\n\n"
        
        return summary
