import json
from datetime import datetime

class OutputFormatter:
    def __init__(self):
        pass
    
    def generate_structured_output(self, main_query, analysis_data):
        """Generate structured JSON output"""
        try:
            structured_data = {
                "query": main_query,
                "timestamp": datetime.now().isoformat(),
                "findings": analysis_data.get('findings', ''),
                "sources": [],
                "contradictions": analysis_data.get('contradictions', []),
                "metadata": {
                    "sources_count": len(analysis_data.get('sources', [])),
                    "analysis_method": "groq-llama3"
                }
            }
            
            # Process sources
            for source in analysis_data.get('sources', []):
                structured_data["sources"].append({
                    "url": source.get('url', ''),
                    "title": source.get('title', ''),
                    "content_length": len(source.get('content', ''))
                })
            
            return structured_data
            
        except Exception as e:
            return {
                "query": main_query,
                "error": f"Failed to format output: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def save_to_file(self, data, filename):
        """Save structured data to JSON file"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Error saving to file: {e}")
            return False
