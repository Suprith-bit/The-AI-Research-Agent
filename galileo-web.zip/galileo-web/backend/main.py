from galileo_agent import GalileoAgent
from config import Config
import sys
import os

def main():
    """Main application entry point"""
    print("🛰️ Project Galileo - Autonomous AI Research Agent")
    print("=" * 50)
    
    # Validate configuration
    if not Config.GOOGLE_API_KEY or not Config.SERPER_API_KEY:
        print("❌ Error: Missing API keys!")
        print("Please set GOOGLE_API_KEY and SERPER_API_KEY in your .env file")
        return
    
    # Initialize agent
    try:
        agent = GalileoAgent()
    except Exception as e:
        print(f"❌ Failed to initialize agent: {e}")
        return
    
    # Test query - you can modify this
    test_queries = [
        "What are the top risks to India's electronics supply chain in the next 12 months?",
        "What are the latest developments in artificial intelligence regulation?",
        "What are the key factors driving renewable energy adoption globally?"
    ]
    
    # Interactive mode or single query mode
    if len(sys.argv) > 1:
        # Use command line argument as query
        query = " ".join(sys.argv[1:])
        print(f"\n🔍 Research Query: {query}")
    else:
        # Use default test query
        query = test_queries[0]
        print(f"\n🔍 Using test query: {query}")
        print("(You can also run: python main.py 'your custom query here')")
    
    # Execute research
    results = agent.research(query)
    
    # Save report
    report_filename = "research_report.md"
    try:
        with open(report_filename, "w", encoding='utf-8') as f:
            f.write(results['report'])
        print(f"\n📄 Report saved as: {report_filename}")
    except Exception as e:
        print(f"❌ Error saving report: {e}")
        print("Report content:")
        print("-" * 40)
        print(results['report'])
    
    # Save structured data
    if results['structured_data']:
        structured_filename = "research_data.json"
        try:
            structured_json = agent.export_structured_data(query, results['structured_data'])
            with open(structured_filename, "w", encoding='utf-8') as f:
                f.write(structured_json)
            print(f"📊 Structured data saved as: {structured_filename}")
        except Exception as e:
            print(f"❌ Error saving structured data: {e}")
    
    # Print summary
    print(f"\n📈 Research Summary:")
    print(f"   Sub-questions generated: {len(results['sub_questions'])}")
    print(f"   Sources analyzed: {results['sources_count']}")
    print(f"   Report length: {len(results['report'])} characters")
    
    # Interactive mode
    print(f"\n💬 Interactive mode available!")
    print("Sample follow-up questions:")
    print("- 'Tell me more about the geopolitical risks'")
    print("- 'What are the specific policy recommendations?'")
    print("- 'Which sources were most reliable?'")
    
    while True:
        try:
            follow_up = input("\n❓ Ask a follow-up question (or 'exit' to quit): ").strip()
            if follow_up.lower() in ['exit', 'quit', 'bye']:
                break
            if follow_up:
                response = agent.chat(follow_up)
                print(f"\n💡 {response}")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"❌ Error: {e}")
    
    print("\n👋 Thank you for using Project Galileo!")

if __name__ == "__main__":
    main()
