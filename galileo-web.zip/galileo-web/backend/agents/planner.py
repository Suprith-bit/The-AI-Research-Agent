from groq import Groq
from config import Config

class QueryPlanner:
    def __init__(self):
        self.client = Groq(api_key=Config.GROQ_API_KEY)
    
    def decompose_query(self, query):
        prompt = f"""Break down this research question into 5 specific sub-questions: "{query}"

Return only the 5 questions, one per line."""
        
        try:
            response = self.client.chat.completions.create(
                model=Config.GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=Config.TEMPERATURE
            )
            
            result = response.choices[0].message.content
            questions = [line.strip() for line in result.split('\n') if line.strip()]
            return questions[:5]
        except Exception as e:
            print(f"Error in query decomposition: {e}")
            return [query]  # Fallback to original query
