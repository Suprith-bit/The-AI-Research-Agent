from groq import Groq
from config import Config

class InformationAnalyst:
    def __init__(self):
        self.client = Groq(api_key=Config.GROQ_API_KEY)
    
    def analyze_content(self, collected_data, sub_questions):
        try:
            # Prepare content for analysis
            content_text = ""
            for item in collected_data:
                content_text += f"Source: {item.get('url', 'Unknown')}\n"
                content_text += f"Content: {item.get('content', '')[:500]}...\n\n"
            
            prompt = f"""Analyze this research content and extract key findings:

{content_text}

Provide a structured analysis with:
1. Key findings
2. Important facts
3. Notable trends

Keep it concise and factual."""
            
            response = self.client.chat.completions.create(
                model=Config.GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=Config.TEMPERATURE
            )
            
            analysis_text = response.choices[0].message.content
            
            return {
                'findings': analysis_text,
                'contradictions': [],
                'sources': collected_data
            }
        except Exception as e:
            print(f"Error in analysis: {e}")
            return {
                'findings': "Analysis unavailable due to error.",
                'contradictions': [],
                'sources': collected_data
            }
