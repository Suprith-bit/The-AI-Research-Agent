import requests
from bs4 import BeautifulSoup
import time
import urllib.parse

class WebScout:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def search_web(self, query):
        """Simplified search using DuckDuckGo HTML scraping"""
        try:
            # Use DuckDuckGo HTML search (more reliable)
            encoded_query = urllib.parse.quote_plus(query[:100])  # Limit query length
            url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
            
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract search results
            results = []
            result_divs = soup.find_all('div', class_='result')
            
            for div in result_divs[:5]:  # Get top 5 results
                title_elem = div.find('h2')
                link_elem = div.find('a', class_='result__url')
                snippet_elem = div.find('a', class_='result__snippet')
                
                if title_elem and link_elem:
                    title = title_elem.get_text(strip=True)
                    link = link_elem.get('href', '')
                    snippet = snippet_elem.get_text(strip=True) if snippet_elem else ''
                    
                    # Clean up the link
                    if link.startswith('//duckduckgo.com/l/?uddg='):
                        continue  # Skip redirect links
                    
                    if link and not link.startswith('http'):
                        link = 'https://' + link
                    
                    results.append({
                        'link': link,
                        'title': title,
                        'snippet': snippet
                    })
            
            print(f"Found {len(results)} search results for: {query[:50]}...")
            return {'organic': results}
            
        except Exception as e:
            print(f"Search error for query '{query[:50]}...': {e}")
            # Fallback: return some basic results to avoid complete failure
            return {
                'organic': [
                    {
                        'link': 'https://example.com',
                        'title': 'Information about: ' + query[:50],
                        'snippet': f'Research information related to {query[:100]}'
                    }
                ]
            }
    
    def scrape_content(self, url):
        """Scrape content from URL"""
        if not url or url == 'https://example.com':
            return None
            
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove unwanted elements
            for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
                tag.decompose()
            
            # Get text content
            text = soup.get_text(separator=' ', strip=True)
            text = ' '.join(text.split())  # Clean whitespace
            
            if len(text) > 100:
                return {
                    'url': url,
                    'content': text[:2000],  # Limit content
                    'title': soup.title.string if soup.title else '',
                    'length': len(text)
                }
                
        except Exception as e:
            print(f"Scraping error for {url}: {e}")
        
        return None
