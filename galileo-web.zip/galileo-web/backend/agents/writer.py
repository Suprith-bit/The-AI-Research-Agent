from groq import Groq
from config import Config

class ReportWriter:
    def __init__(self):
        self.client = Groq(api_key=Config.GROQ_API_KEY)
    
    def generate_report(self, main_query, analysis):
        try:
            findings = analysis.get('findings', 'No findings available')
            sources = analysis.get('sources', [])
            
            # Create source list
            source_urls = []
            for source in sources:
                if source.get('url'):
                    source_urls.append(source['url'])
            
            prompt = f"""Create a professional research report for: "{main_query}"

Based on this analysis:
{findings}

Format as a markdown report with:
- Title
- Executive Summary
- Key Findings
- Sources

Include proper citations and keep it professional."""
            
            response = self.client.chat.completions.create(
                model=Config.GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=2000,
                temperature=Config.TEMPERATURE
            )
            
            report = response.choices[0].message.content
            
            # Add sources at the end
            if source_urls:
                report += "\n\n## Sources\n\n"
                for i, url in enumerate(source_urls, 1):
                    report += f"{i}. {url}\n"
            
            return report
            
        except Exception as e:
            print(f"Error generating report: {e}")
            return f"# Research Report\n\nQuery: {main_query}\n\nError generating report: {str(e)}"
