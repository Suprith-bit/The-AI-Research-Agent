from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from galileo_agent import GalileoAgent

app = FastAPI(title="Project Galileo API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

agent = GalileoAgent()

class ResearchRequest(BaseModel):
    query: str

@app.get("/")
async def root():
    return {"message": "Project Galileo API is running"}

@app.post("/api/research")
async def research(request: ResearchRequest):
    print(f"🔍 Received research request: {request.query}")
    try:
        results = agent.research(request.query)
        print(f"✅ Research completed successfully")
        
        response_data = {
            "report": str(results.get('report', 'No report generated')),
            "sources_count": int(results.get('sources_count', 0)),
            "sub_questions": list(results.get('sub_questions', []))
        }
        
        print(f"📊 Sending response with {len(response_data['report'])} character report")
        return response_data
        
    except Exception as e:
        print(f"❌ Research failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
