import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    GROQ_MODEL = "llama-3.1-8b-instant"
    TEMPERATURE = 0.3
    MAX_TOKENS = 2000
    MAX_SEARCH_RESULTS = 5
    MAX_SCRAPE_ATTEMPTS = 3
    REQUEST_TIMEOUT = 10
    REPORT_FORMAT = "markdown"
